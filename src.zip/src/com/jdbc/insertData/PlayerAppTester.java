package com.jdbc.insertData;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.jdbc.dbutil.OracleDBConnection;

public class PlayerAppTester {
	public static void main(String[] args) throws Exception {

		String dob = "10.05.1997";

		Date d = new SimpleDateFormat("dd.MM.yyyy").parse(dob);

		Player p = new Player();

		Player player = new Player(161, "Ankit", 25, "M", "ankita@gmail.com", "Pakistan", 987609876,
				new java.sql.Date(d.getTime()));
		System.out.println("Data inserted");

		Connection connection = null;

		try {
			connection = OracleDBConnection.getConnection();
			String sql = "insert into PLAYER(id,name,age, gender, email, teamName, contact, dob)"
					+ "values(?,?,?,?,?,?,?,?)";

			PreparedStatement pstmt = connection.prepareStatement(sql);

			pstmt.setInt(1, player.getId());
			pstmt.setString(2, player.getName());
			pstmt.setInt(3, player.getAge());
			pstmt.setString(4, player.getGender());
			pstmt.setString(5, player.getEmail());
			pstmt.setString(6, player.getTeamName());
			pstmt.setLong(7, player.getContactNumber());
			pstmt.setDate(8, new java.sql.Date(player.getDob().getTime()));

			// System.out.println("Done");

			int count = pstmt.executeUpdate();
			System.out.println(count + " numbe rof records gets inserted");

			System.out.println("Done");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
					System.out.println("Finally block");
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
