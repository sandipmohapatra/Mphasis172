package com.jdbc.insertData;

import java.io.Serializable;
import java.util.Date;

public class Player implements Serializable {

	private int id;
	private String name;
	private int age;
	private String gender;
	private String email;
	private String teamName;
	private long contact;
	private Date dob;

	public Player() {
		System.out.println(this.getClass().getSimpleName() + " class object created");
	}

	public Player(int id, String name, int age, String gender, String email, String teamName, long contactNumber,
			Date dob) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.email = email;
		this.teamName = teamName;
		this.contact = contactNumber;
		this.dob = dob;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public long getContactNumber() {
		return contact;
	}

	public void setContactNumber(long contactNumber) {
		this.contact = contactNumber;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

}
